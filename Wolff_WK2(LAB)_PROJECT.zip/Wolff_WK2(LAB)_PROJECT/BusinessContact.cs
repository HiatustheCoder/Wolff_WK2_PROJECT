// Demonstration of Polymorphism:
// BusinessContact overrides GetContactInfo() with its own business-specific information.
public class BusinessContact : Contact
{
    public string Company { get; set; }

    public BusinessContact(string name, string phoneNumber, string email, string address, string company)
        : base(name, phoneNumber, email, address)
    {
        Company = company;
    }

    public override string GetContactInfo()
    {
        return base.GetContactInfo() + string.Format("\nCompany: {0}", Company);
    }
}