// Demonstration of Interfaces:
// Contact implements IContactDisplay by providing GetContactInfo().
public class Contact : IContactDisplay {
    public string Name {get; set;}
    public string PhoneNumber {get; set;}
    public string Email {get; set;}
    public string Address {get; set;}

    public Contact (string name, string phoneNumber, string email, string address)
    {
        Name = name;
        PhoneNumber = phoneNumber;
        Email = email;
        Address = address;
    }
    public virtual string GetContactInfo()
    {
        return string.Format(" Name: {0} \n PhoneNumber: {1} \nEmail {2} \nAddress {3}", Name, PhoneNumber, Email, Address);
    }
    public override string ToString()
    {
        return GetContactInfo();
    }

}