// Demonstration of Interfaces:
// This interface defines the GetContactInfo() contract that contact classes must follow.
public interface IContactDisplay
{
    string GetContactInfo();
}