// Demonstration of Polymorphism:
// PersonalContact overrides GetContactInfo() with its own personal-specific information.
public class PersonalContact : Contact
{
    public string Relationship { get; set; }

    public PersonalContact(string name, string phoneNumber, string email, string address, string relationship)
        : base(name, phoneNumber, email, address)
    {
        Relationship = relationship;
    }

    public override string GetContactInfo()
    {
        return base.GetContactInfo() + string.Format("\nRelationship: {0}", Relationship);
    }
}