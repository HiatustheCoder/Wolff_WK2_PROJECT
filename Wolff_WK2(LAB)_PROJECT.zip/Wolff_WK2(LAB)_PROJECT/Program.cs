﻿using System;

public class Program
{
    static void Main(string[] args)
    {
        // Composition demonstrated here:
        // Rolodex object contains Contact objects
        Rolodex myRolodex = new Rolodex();

        // Inheritance demonstrated here:
        // BusinessContact and PersonalContact are child classes of Contact
        BusinessContact contact1 = new BusinessContact(
            "John Doe",
            "555-1234",
            "john@email.com",
            "123 Main St",
            "ABC Company"
        );

        PersonalContact contact2 = new PersonalContact(
            "Jane Doe",
            "555-5678",
            "jane@email.com",
            "456 Oak Ave",
            "Friend"
        );

        string choice = "";

        Console.WriteLine("Dalvin Wolff - Week 1 Project Assignment");
        Console.WriteLine("Rolodex / Contact Manager");
        Console.WriteLine("Welcome to the contact manager.");
        Console.WriteLine("Choose an option from the menu below.");
        Console.WriteLine();

        while (choice != "3")
        {
            Console.WriteLine("1. Add");
            Console.WriteLine("2. Display");
            Console.WriteLine("3. Exit");
            Console.Write("Enter choice: ");
            choice = Console.ReadLine()?.Trim() ?? "";

            if (choice == "1")
            {
                myRolodex.AddContact(contact1);
                myRolodex.AddContact(contact2);

                Console.WriteLine();
                Console.WriteLine("Contacts added.");
                Console.WriteLine();
            }
            else if (choice == "2")
            {
                Console.WriteLine();

                if (myRolodex.Contacts.Count == 0)
                {
                    Console.WriteLine("No contacts stored.");
                }
                else
                {
                    Console.WriteLine("Stored Contacts");
                    myRolodex.DisplayContacts();
                }

                Console.WriteLine();
            }
            else if (choice == "3")
            {
                Console.WriteLine();
                Console.WriteLine("Exiting program...");
            }
            else
            {
                Console.WriteLine();
                Console.WriteLine("Invalid choice. Please enter 1, 2, or 3.");
                Console.WriteLine();
            }
        }
    }
}