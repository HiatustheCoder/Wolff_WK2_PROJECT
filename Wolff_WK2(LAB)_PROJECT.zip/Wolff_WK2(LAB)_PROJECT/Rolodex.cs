using System;
using System.Collections.Generic;

public class Rolodex
{
    public List<Contact> Contacts { get; set;}

    public Rolodex()
    {
        Contacts = new List<Contact>();
    }
    public void AddContact(Contact contact)
    {
        Contacts.Add(contact);
    }
    public void AddContact(string name, string phoneNumber, string email, string address)
    {
        Contacts.Add(new Contact(name, phoneNumber, email, address));
    }
// Demonstration of Polymorphism:
// The Rolodex stores different derived contact objects in a List<Contact>
// and displays them through the same method call.
    public void DisplayContacts() 
    {
        foreach (var item in Contacts)
        {
            Console.WriteLine(item);
        }
    }
}